library(shiny)
library(WhatsInSeason)

# Define UI ----
ui <- fluidPage(

  navbarPage(title = "Water Footprint Data",
    tabPanel("Global Water Footprint",
             sidebarLayout(
               sidebarPanel(textInput(inputId = "food",
                                      label = "search food",
                                      placeholder = "search food item here"),
                            plotOutput(outputId = "pic")),
               mainPanel(
                 tableOutput(outputId = "globaltable"),
                 plotOutput(outputId = "globalplot")))),

    tabPanel("National Water Footprint",
             sidebarLayout(
               sidebarPanel(textInput(inputId = "foodnational",
                                      label = "Search food",
                                      placeholder = "search food item here"),
                            selectInput(inputId = "continent",
                                        label = "Continent:",
                                        choices = c("Americas", "Africa", "Asia", "Oceania", "Europe")),
                            textInput(inputId = "countrycode",
                                      label = "Country Code:",
                                      placeholder = "enter FIPS code"),
                            tags$body("Country code should be entered according to the FIPS countrycodes.
                                      See the table below for an overview of country codes."),
                            tableOutput(outputId = "countrycodes")),
               mainPanel(
                 tableOutput(outputId = "nationaltable"),
                 plotOutput(outputId = "nationalplot",
                            width = 900,
                            height = 900)))),

    tabPanel("Regional Water Footprint",
             sidebarLayout(
               sidebarPanel(textInput(inputId = "countryname",
                                      label = "Country:",
                                      placeholder = "input country"),
                            textInput(inputId = "foodregional",
                                      label = "search food",
                                      placeholder = "search food item here")),
               mainPanel(
                 tableOutput(outputId = "regionaltable"),
                 plotOutput(outputId = "regionalplot")))),

    tabPanel("Nutritional Data",
             sidebarLayout(
               sidebarPanel(textInput(inputId = "foodnutrition",
                                      label = "search food",
                                      placeholder = "search food item here")),
               mainPanel(tabsetPanel(
                 tabPanel("Table", tableOutput("tablenutrition")),
                 tabPanel("Plot", plotOutput("plotnutrition"))
               ))
             ))
    )
)



# Define server logic ----
server <- function(input, output) {

  output$pic <- renderPlot({
    food_pic(input$food)
  })
  output$globalplot <- renderPlot({
    plot_wf_global(input$food)
  })
  output$globaltable <- renderTable({
    as.data.frame(wf_global(input$food))
  })
  output$nationaltable <- renderTable({
    as.data.frame(wf_country(input$foodnational, input$countrycode))
  })
  output$nationalplot <- renderPlot({
    wf_country_plot(input$foodnational, input$continent)
  })
  output$countrycodes <- renderTable({
    as.data.frame(countrycodes(input$continent))[, c(1, 3)]
  })
  output$regionaltable <- renderTable({
    as.data.frame(wf_region(input$foodregional, input$countryname))
  })
  output$regionalplot <- renderPlot({
    wf_region_plot(input$foodregional, input$countryname)
  })
  output$plotnutrition <- renderPlot({
    plot_nutrients(input$foodnutrition)
  })

}

# Run App ----
shinyApp(ui, server)







