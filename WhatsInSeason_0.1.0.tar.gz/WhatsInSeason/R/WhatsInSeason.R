#' WhatsInSeason: Food information for seasonal and healthy eating!
#'
#' @section Seasonal Food Functions:
#'
#'
#' @section Nutrition Functions:
#'
#'    With the nutrition functions, you can:
#'    Search for foods and their corresponding nutritional information with search_food()
#'    Get specific nutritional information for food items with get_nutrients()
#'    Compare nutritional information of two different food items with compare_nutrients()
#'    Plot nutritional information of a food item with plot_nutrients()
#'
#' @docType package
#' @name WhatsInSeason
NULL
#> NULL
