library(testthat)
library(WhatsInSeason)

test_check("WhatsInSeason")
