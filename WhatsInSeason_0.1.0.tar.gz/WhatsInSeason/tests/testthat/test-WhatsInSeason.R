library(WhatsInSeason)

context("Core WhatsInSeason functionality")

test_that("search_food returns the corresponding search hit", {

  sf <- search_food("potato")
  expect_equal(adist(sf[1, 1], "potato", ignore.case = TRUE)[1], 0)

})

test_that("all search results contain search query", {

  sf <- search_food("potato")$label
  expect_equal(length(grepl("potato", sf, ignore.case = TRUE)), 9)

})




