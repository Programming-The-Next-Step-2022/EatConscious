library(WhatsInSeason)

context("Core WhatsInSeason functionality")

# test_that("search_food returns the correct search hit", {
#
# })

test_that("search_food returns a table of the correct dimensions", {

  dim <- c(9, 6)
  sf <- search_food("potato")
  expect_equal(dim(sf), dim)

})
