library(testthat)
library(EatConscious)

test_check("EatConscious")
