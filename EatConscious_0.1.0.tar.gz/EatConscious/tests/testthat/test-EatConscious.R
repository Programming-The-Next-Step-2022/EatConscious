library(EatConscious)

# -------------------------------------------
# Tests for search_food function
# -------------------------------------------

test_that("search_food returns the corresponding search hit", {

  sf <- search_food("potato")$nutrients
  expect_equal(adist(sf[1, 1], "potato", ignore.case = TRUE)[1], 0)

})

test_that("all search results contain search query", {

  sf <- search_food("potato")$nutrients[, "search_result"]
  expect_equal(length(grepl("potato", sf, ignore.case = TRUE)), 9)

})

# -------------------------------------------
# Tests for water footprint functions
# -------------------------------------------

test_that("wf_global returns correct dataframe", {

  wf_global <- wf_global("potato")
  df <- data.frame(Product = rep("Potatoes, fresh or chilled nes", 3),
                   WF_Type = as.factor(c("Green", "Blue", "Grey")),
                   AverageWF = c(191, 33, 63))
  row.names(df) <- c(154:156)

  expect_equal(wf_global, df)

})




